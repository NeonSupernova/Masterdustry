var mod = Vars.mods.locateMod("masterdustry");
var x = mod.meta;
x.displayName = "[#af6ecc]Masterdustry";
x.description = "[#f2ed5e]Fun little beginner mod with some op stuff.";
x.author = "[#af6ecc]Techycat";
