//require("mod");


Vars.defaultServers.clear();
Vars.defaultServers.add(ServerGroup("Unjown Server", ["braindustryserver.ddns.net:25647"]));
//require("rotators");
